package com.reznik.krd.ssmdiagramplugin.ui.diagram

import com.intellij.ui.JBColor
import com.reznik.krd.ssmdiagramplugin.model.SsmState
import com.reznik.krd.ssmdiagramplugin.model.StateMachineModel
import com.reznik.krd.ssmdiagramplugin.ui.diagram.builder.DiagramGraphBuilder
import com.reznik.krd.ssmdiagramplugin.ui.diagram.layout.DiagramLayout
import com.reznik.krd.ssmdiagramplugin.ui.diagram.layout.EdgeLayout
import com.reznik.krd.ssmdiagramplugin.ui.diagram.layout.HierarchicalLayoutEngine
import com.reznik.krd.ssmdiagramplugin.ui.diagram.model.DiagramEdge
import com.reznik.krd.ssmdiagramplugin.ui.diagram.model.DiagramGraph
import com.reznik.krd.ssmdiagramplugin.ui.diagram.model.DiagramNode
import com.reznik.krd.ssmdiagramplugin.ui.diagram.transform.ReadableGraphTransformer
import java.awt.*
import javax.swing.JPanel

class SsmDiagramPanel : JPanel() {

    private val graphBuilder = DiagramGraphBuilder()
    private val layoutEngine = HierarchicalLayoutEngine()
    private val graphTransformer = ReadableGraphTransformer()
    private var graph: DiagramGraph? = null
    private var layout: DiagramLayout? = null

    private val nodeWidth = 180
    private val nodeHeight = 60

    private val horizontalGap = 140
    private val verticalGap = 80

    init {
        background = JBColor.PanelBackground
    }

    fun setModel(model: StateMachineModel) {

        val logicalGraph =
            graphBuilder.build(model)

        val visualGraph =
            graphTransformer.transform(
                logicalGraph
            )

        val layout =
            layoutEngine.layout(
                visualGraph
            )

        this.graph = visualGraph
        this.layout = layout

        preferredSize = layout.size

        revalidate()
        repaint()
    }

    override fun paintComponent(g: Graphics) {
        super.paintComponent(g)

        val graph = graph ?: return
        val layout = layout ?: return

        val g2 = g.create() as Graphics2D

        try {

            configureGraphics(g2)

            drawEdges(
                g2,
                graph,
                layout
            )

            drawNodes(
                g2,
                graph,
                layout
            )

        } finally {
            g2.dispose()
        }
    }

    private fun drawNodes(
        g2: Graphics2D,
        graph: DiagramGraph,
        layout: DiagramLayout
    ) {

        graph.nodes.forEach { node ->

            val nodeLayout =
                layout.nodes[node.id]
                    ?: return@forEach

            val point =
                Point(
                    nodeLayout.x,
                    nodeLayout.y
                )

            when (node.type) {

                DiagramNode.Type.INITIAL_MARKER ->
                    drawInitialMarker(
                        g2,
                        point
                    )

                DiagramNode.Type.END_MARKER ->
                    drawEndMarker(
                        g2,
                        point
                    )

                DiagramNode.Type.CHOICE ->
                    drawChoiceNode(
                        g2,
                        node,
                        point
                    )

                DiagramNode.Type.STATE ->
                    drawStateNode(
                        g2,
                        node,
                        point
                    )
            }
        }
    }

    private fun drawInitialMarker(
        g2: Graphics2D,
        point: Point
    ) {

        val centerX =
            point.x + nodeWidth / 2

        val centerY =
            point.y + nodeHeight / 2

        val radius = 8

        g2.color = JBColor.foreground()

        g2.fillOval(
            centerX - radius,
            centerY - radius,
            radius * 2,
            radius * 2
        )
    }

    private fun drawEndMarker(
        g2: Graphics2D,
        point: Point
    ) {

        val centerX =
            point.x + nodeWidth / 2

        val centerY =
            point.y + nodeHeight / 2

        val outerRadius = 10
        val innerRadius = 5

        g2.color = JBColor.foreground()

        g2.drawOval(
            centerX - outerRadius,
            centerY - outerRadius,
            outerRadius * 2,
            outerRadius * 2
        )

        g2.fillOval(
            centerX - innerRadius,
            centerY - innerRadius,
            innerRadius * 2,
            innerRadius * 2
        )
    }

    private fun drawStateNode(
        g2: Graphics2D,
        node: DiagramNode,
        point: Point
    ) {

        g2.color = JBColor.PanelBackground

        g2.fillRoundRect(
            point.x,
            point.y,
            nodeWidth,
            nodeHeight,
            16,
            16
        )

        g2.color = JBColor.foreground()

        g2.drawRoundRect(
            point.x,
            point.y,
            nodeWidth,
            nodeHeight,
            16,
            16
        )

        drawCenteredText(
            g2,
            node.label,
            point.x,
            point.y,
            nodeWidth,
            nodeHeight
        )
    }

    private fun drawChoiceNode(
        g2: Graphics2D,
        node: DiagramNode,
        point: Point
    ) {

        val centerX =
            point.x + nodeWidth / 2

        val centerY =
            point.y + nodeHeight / 2

        val size = 25

        val polygon = Polygon(
            intArrayOf(
                centerX,
                centerX + size,
                centerX,
                centerX - size
            ),
            intArrayOf(
                centerY - size,
                centerY,
                centerY + size,
                centerY
            ),
            4
        )

        g2.color = JBColor.PanelBackground
        g2.fillPolygon(polygon)

        g2.color = JBColor.foreground()
        g2.drawPolygon(polygon)

        g2.drawString(
            node.label,
            centerX + size + 10,
            centerY + 5
        )
    }

    private fun configureGraphics(g2: Graphics2D) {

        g2.setRenderingHint(
            RenderingHints.KEY_ANTIALIASING,
            RenderingHints.VALUE_ANTIALIAS_ON
        )

        g2.setRenderingHint(
            RenderingHints.KEY_TEXT_ANTIALIASING,
            RenderingHints.VALUE_TEXT_ANTIALIAS_ON
        )
    }

    private fun drawStates(
        g2: Graphics2D,
        model: StateMachineModel,
        positions: Map<String, Point>
    ) {

        model.states.forEach { state ->

            val point = positions[state.name]
                ?: return@forEach

            drawState(
                g2,
                state,
                point
            )
        }
    }

    private fun drawState(
        g2: Graphics2D,
        state: SsmState,
        point: Point
    ) {

        when (state.type) {

            SsmState.Type.CHOICE ->
                drawChoiceState(g2, state, point)

            else ->
                drawNormalState(g2, state, point)
        }
    }

    private fun drawNormalState(
        g2: Graphics2D,
        state: SsmState,
        point: Point
    ) {

        g2.color = JBColor.PanelBackground

        g2.fillRoundRect(
            point.x,
            point.y,
            nodeWidth,
            nodeHeight,
            16,
            16
        )

        g2.color = JBColor.foreground()

        g2.drawRoundRect(
            point.x,
            point.y,
            nodeWidth,
            nodeHeight,
            16,
            16
        )

        drawCenteredText(
            g2,
            state.name,
            point.x,
            point.y,
            nodeWidth,
            nodeHeight
        )
    }

    private fun drawChoiceState(
        g2: Graphics2D,
        state: SsmState,
        point: Point
    ) {

        val centerX = point.x + nodeWidth / 2
        val centerY = point.y + nodeHeight / 2

        val size = 26

        val polygon = Polygon(
            intArrayOf(
                centerX,
                centerX + size,
                centerX,
                centerX - size
            ),
            intArrayOf(
                centerY - size,
                centerY,
                centerY + size,
                centerY
            ),
            4
        )

        g2.color = JBColor.PanelBackground
        g2.fillPolygon(polygon)

        g2.color = JBColor.foreground()
        g2.drawPolygon(polygon)

        g2.drawString(
            state.name,
            centerX + size + 10,
            centerY + 5
        )
    }

    private fun drawCenteredText(
        g2: Graphics2D,
        text: String,
        x: Int,
        y: Int,
        width: Int,
        height: Int
    ) {

        val metrics = g2.fontMetrics

        val textX =
            x + (width - metrics.stringWidth(text)) / 2

        val textY =
            y + (height - metrics.height) / 2 +
                    metrics.ascent

        g2.drawString(
            text,
            textX,
            textY
        )
    }

    private fun drawEdges(
        g2: Graphics2D,
        graph: DiagramGraph,
        layout: DiagramLayout
    ) {

        graph.edges.forEach { edge ->

            val edgeLayout =
                layout.edges[edge]
                    ?: return@forEach

            val points =
                edgeLayout.points

            if (points.size < 2) {
                return@forEach
            }

            g2.color = JBColor.foreground()

            /*
             * Рисуем каждый сегмент маршрута.
             */

            points
                .zipWithNext()
                .forEach { (from, to) ->

                    g2.drawLine(
                        from.x,
                        from.y,
                        to.x,
                        to.y
                    )
                }

            /*
             * Arrowhead только на последнем сегменте.
             */

            val beforeEnd =
                points[points.lastIndex - 1]

            val end =
                points.last()

            drawArrow(
                g2,
                beforeEnd.x,
                beforeEnd.y,
                end.x,
                end.y
            )

            drawEdgeLabel(
                g2,
                edge,
                edgeLayout
            )
        }
    }

    private fun drawEdgeLabel(
        g2: Graphics2D,
        edge: DiagramEdge,
        edgeLayout: EdgeLayout
    ) {

        if (
            edge.type == DiagramEdge.Type.INITIAL ||
            edge.type == DiagramEdge.Type.END
        ) {
            return
        }

        val labels = mutableListOf<String>()

        edge.event?.let {
            labels += it
        }

        edge.guard?.let {
            labels += "[${it.name}]"
        }

        if (
            edge.type == DiagramEdge.Type.CHOICE_BRANCH &&
            edge.guard == null
        ) {
            labels += "otherwise"
        }

        if (labels.isEmpty()) {
            return
        }

        val position =
            edgeLayout.labelPosition
                ?: return

        val text =
            labels.joinToString(" ")

        g2.drawString(
            text,
            position.x,
            position.y
        )
    }

    private fun drawArrow(
        g2: Graphics2D,
        x1: Int,
        y1: Int,
        x2: Int,
        y2: Int
    ) {

        val angle =
            Math.atan2(
                (y2 - y1).toDouble(),
                (x2 - x1).toDouble()
            )

        val arrowSize = 10.0

        val angle1 = angle - Math.PI / 6
        val angle2 = angle + Math.PI / 6

        val x3 =
            x2 - arrowSize * Math.cos(angle1)

        val y3 =
            y2 - arrowSize * Math.sin(angle1)

        val x4 =
            x2 - arrowSize * Math.cos(angle2)

        val y4 =
            y2 - arrowSize * Math.sin(angle2)

        g2.drawLine(
            x2,
            y2,
            x3.toInt(),
            y3.toInt()
        )

        g2.drawLine(
            x2,
            y2,
            x4.toInt(),
            y4.toInt()
        )
    }

}