package com.reznik.krd.ssmdiagramplugin.ui.diagram.layout

import com.reznik.krd.ssmdiagramplugin.ui.diagram.model.DiagramEdge
import java.awt.Dimension

data class DiagramLayout(
    val nodes: Map<String, NodeLayout>,
    val edges: Map<DiagramEdge, EdgeLayout>,
    val size: Dimension
)