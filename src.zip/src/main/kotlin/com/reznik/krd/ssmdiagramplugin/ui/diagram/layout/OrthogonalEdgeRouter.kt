package com.reznik.krd.ssmdiagramplugin.ui.diagram.layout

import com.reznik.krd.ssmdiagramplugin.ui.diagram.model.DiagramEdge
import com.reznik.krd.ssmdiagramplugin.ui.diagram.model.DiagramGraph
import java.awt.Point

class OrthogonalEdgeRouter {

    fun route(
        graph: DiagramGraph,
        nodes: Map<String, NodeLayout>
    ): Map<DiagramEdge, EdgeLayout> {

        return graph.edges.associateWith { edge ->

            val source =
                nodes[edge.source]
                    ?: return@associateWith EdgeLayout(
                        points = emptyList(),
                        labelPosition = null
                    )

            val target =
                nodes[edge.target]
                    ?: return@associateWith EdgeLayout(
                        points = emptyList(),
                        labelPosition = null
                    )

            routeEdge(
                source,
                target
            )
        }
    }

    private fun routeEdge(
        source: NodeLayout,
        target: NodeLayout
    ): EdgeLayout {

        if (target.y == source.y) {
            return routeHorizontal(
                source,
                target
            )
        }

        if (target.y > source.y) {
            return routeDownward(
                source,
                target
            )
        }

        return routeBackward(
            source,
            target
        )
    }

    private fun routeHorizontal(
        source: NodeLayout,
        target: NodeLayout
    ): EdgeLayout {

        val start =
            if (target.x > source.x) {
                source.right
            } else {
                source.left
            }

        val end =
            if (target.x > source.x) {
                target.left
            } else {
                target.right
            }

        return EdgeLayout(
            points = listOf(
                start,
                end
            ),

            labelPosition = Point(
                (start.x + end.x) / 2,
                start.y - 8
            )
        )
    }

    private fun routeDownward(
        source: NodeLayout,
        target: NodeLayout
    ): EdgeLayout {

        val start = source.bottom
        val end = target.top

        /*
         * Если nodes стоят друг под другом —
         * идеальная вертикальная линия.
         */

        if (start.x == end.x) {

            return EdgeLayout(
                points = listOf(
                    start,
                    end
                ),
                labelPosition = Point(
                    start.x + 8,
                    (start.y + end.y) / 2
                )
            )
        }

        val middleY =
            (start.y + end.y) / 2

        val firstCorner =
            Point(
                start.x,
                middleY
            )

        val secondCorner =
            Point(
                end.x,
                middleY
            )

        return EdgeLayout(
            points = listOf(
                start,
                firstCorner,
                secondCorner,
                end
            ),

            labelPosition = Point(
                (firstCorner.x + secondCorner.x) / 2,
                middleY - 6
            )
        )
    }

    private fun routeBackward(
        source: NodeLayout,
        target: NodeLayout
    ): EdgeLayout {

        val start = source.right
        val end = target.right

        val sideX =
            maxOf(
                start.x,
                end.x
            ) + 50

        val firstCorner =
            Point(
                sideX,
                start.y
            )

        val secondCorner =
            Point(
                sideX,
                end.y
            )

        return EdgeLayout(
            points = listOf(
                start,
                firstCorner,
                secondCorner,
                end
            ),

            labelPosition = Point(
                sideX + 8,
                (start.y + end.y) / 2
            )
        )
    }
}