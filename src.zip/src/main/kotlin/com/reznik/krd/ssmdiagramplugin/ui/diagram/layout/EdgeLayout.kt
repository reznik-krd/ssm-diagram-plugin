package com.reznik.krd.ssmdiagramplugin.ui.diagram.layout

import java.awt.Point

data class EdgeLayout(
    val points: List<Point>,
    val labelPosition: Point?
)