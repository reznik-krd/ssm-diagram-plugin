package com.reznik.krd.ssmdiagramplugin.ui.diagram.model

import com.reznik.krd.ssmdiagramplugin.model.SsmState

data class DiagramNode(
    /**
     * Уникальный ID именно визуального node.
     *
     * Например:
     * CANCELLED__copy__CREATED
     */
    val id: String,

    /**
     * ID настоящего состояния StateMachine.
     *
     * Для нескольких visual copies будет одинаковым:
     * CANCELLED
     */
    val logicalId: String,

    val label: String,
    val type: Type,
    val state: SsmState? = null,

    val visualCopy: Boolean = false,

    /**
     * Для visual copy:
     * рядом с каким source желательно её разместить.
     */
    val preferredParentId: String? = null,

    val placement: Placement = Placement.NORMAL
) {

    enum class Type {
        INITIAL_MARKER,
        STATE,
        END_MARKER,
        CHOICE
    }

    enum class Placement {
        NORMAL,
        SIDE
    }
}