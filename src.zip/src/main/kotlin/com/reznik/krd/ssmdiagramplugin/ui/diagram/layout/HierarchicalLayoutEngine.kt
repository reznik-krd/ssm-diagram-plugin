package com.reznik.krd.ssmdiagramplugin.ui.diagram.layout

import com.reznik.krd.ssmdiagramplugin.ui.diagram.model.DiagramGraph
import com.reznik.krd.ssmdiagramplugin.ui.diagram.model.DiagramNode
import java.awt.Dimension
import java.awt.Point
import java.util.ArrayDeque

class HierarchicalLayoutEngine {

    private val edgeRouter =
        OrthogonalEdgeRouter()

    private val nodeWidth = 180
    private val nodeHeight = 60

    private val horizontalGap = 100
    private val verticalGap = 100

    private val margin = 80

    fun layout(graph: DiagramGraph): DiagramLayout {

        if (graph.nodes.isEmpty()) {
            return DiagramLayout(
                nodes = emptyMap(),
                edges = emptyMap(),
                size = Dimension(500, 500)
            )
        }

        val levels = calculateLevels(graph)

        val normalNodes =
            graph.nodes.filter {
                it.placement ==
                        DiagramNode.Placement.NORMAL
            }

        val groupedByLevel =
            normalNodes
                .groupBy {
                    levels[it.id] ?: 0
                }
                .toSortedMap()

        val nodes =
            mutableMapOf<String, NodeLayout>()

        val maxNodesInLevel =
            groupedByLevel.values
                .maxOfOrNull { it.size }
                ?: 1

        val contentWidth =
            maxNodesInLevel * nodeWidth +
                    (maxNodesInLevel - 1) * horizontalGap

        groupedByLevel.forEach { (level, levelNodes) ->

            val rowWidth =
                levelNodes.size * nodeWidth +
                        (levelNodes.size - 1) * horizontalGap

            var x =
                margin +
                        (contentWidth - rowWidth) / 2

            val y =
                margin +
                        level * (nodeHeight + verticalGap)

            levelNodes.forEach { node ->

                nodes[node.id] =
                    NodeLayout(
                        x = x,
                        y = y,
                        width = nodeWidth,
                        height = nodeHeight
                    )

                x += nodeWidth + horizontalGap
            }
        }
        placeSideNodes(
            graph,
            nodes
        )

        val edges =
            edgeRouter.route(
                graph,
                nodes
            )

        val maxLevel =
            groupedByLevel.keys.maxOrNull() ?: 0

        val width =
            contentWidth + margin * 2 + 150

        val height =
            margin * 2 +
                    (maxLevel + 1) * nodeHeight +
                    maxLevel * verticalGap

        return DiagramLayout(
            nodes = nodes,
            edges = edges,
            size = Dimension(
                maxOf(width, 600),
                maxOf(height, 500)
            )
        )
    }

    private fun placeSideNodes(
        graph: DiagramGraph,
        layouts: MutableMap<String, NodeLayout>
    ) {

        val sideGap = 120

        graph.nodes
            .filter {
                it.placement ==
                        DiagramNode.Placement.SIDE
            }
            .forEach { node ->

                val parentId =
                    node.preferredParentId
                        ?: return@forEach

                val parent =
                    layouts[parentId]
                        ?: return@forEach

                layouts[node.id] =
                    NodeLayout(
                        x = parent.x +
                                parent.width +
                                sideGap,

                        y = parent.y,

                        width = nodeWidth,
                        height = nodeHeight
                    )
            }
    }

    private fun calculateLevels(
        graph: DiagramGraph
    ): Map<String, Int> {

        val levels = mutableMapOf<String, Int>()

        val roots = findRoots(graph)

        val queue = ArrayDeque<DiagramNode>()

        roots.forEach { root ->
            levels[root.id] = 0
            queue.add(root)
        }

        while (queue.isNotEmpty()) {

            val current = queue.removeFirst()

            val currentLevel =
                levels[current.id] ?: 0

            graph.outgoing(current.id)
                .forEach { edge ->

                    val target =
                        graph.node(edge.target)
                            ?: return@forEach

                    val proposedLevel =
                        currentLevel + 1

                    val existingLevel =
                        levels[target.id]

                    /*
                     * Первый проход.
                     *
                     * Не пытаемся бесконечно двигать вершины
                     * вниз при циклах.
                     */
                    if (existingLevel == null) {

                        levels[target.id] =
                            proposedLevel

                        queue.add(target)
                    }
                }
        }

        /*
         * Состояния, до которых не дошли от root,
         * всё равно должны попасть на схему.
         */

        val nextLevel =
            (levels.values.maxOrNull() ?: -1) + 1

        graph.nodes
            .filter { it.id !in levels }
            .forEach {
                levels[it.id] = nextLevel
            }

        return levels
    }

    private fun findRoots(
        graph: DiagramGraph
    ): List<DiagramNode> {

        /*
         * Spring INITIAL имеет приоритет.
         */

        val initialNodes =
            graph.nodes.filter {
                it.type == DiagramNode.Type.INITIAL_MARKER
            }

        if (initialNodes.isNotEmpty()) {
            return initialNodes
        }

        /*
         * Fallback:
         * вершины без входящих рёбер.
         */

        val roots =
            graph.nodes.filter {
                graph.incoming(it.id).isEmpty()
            }

        if (roots.isNotEmpty()) {
            return roots
        }

        /*
         * Совсем странный граф:
         * например сплошной цикл.
         */

        return listOf(graph.nodes.first())
    }
}