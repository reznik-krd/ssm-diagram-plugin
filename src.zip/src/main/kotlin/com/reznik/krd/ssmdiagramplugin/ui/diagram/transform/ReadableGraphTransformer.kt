package com.reznik.krd.ssmdiagramplugin.ui.diagram.transform

import com.reznik.krd.ssmdiagramplugin.ui.diagram.model.DiagramEdge
import com.reznik.krd.ssmdiagramplugin.ui.diagram.model.DiagramGraph
import com.reznik.krd.ssmdiagramplugin.ui.diagram.model.DiagramNode

class ReadableGraphTransformer {

    companion object {
        private const val MIN_INCOMING_FOR_DUPLICATION = 2
    }

    fun transform(
        graph: DiagramGraph
    ): DiagramGraph {

        val candidates =
            findDuplicationCandidates(graph)

        if (candidates.isEmpty()) {
            return graph
        }

        val nodes =
            graph.nodes.toMutableList()

        val edges =
            graph.edges.toMutableList()

        candidates.forEach { candidate ->

            duplicateTerminalNode(
                candidate,
                nodes,
                edges
            )
        }

        return DiagramGraph(
            nodes = nodes,
            edges = edges
        )
    }

    private fun findDuplicationCandidates(
        graph: DiagramGraph
    ): List<DiagramNode> {

        return graph.nodes.filter { node ->

            if (node.type != DiagramNode.Type.STATE) {
                return@filter false
            }

            val incoming =
                graph.incoming(node.id)

            val outgoing =
                graph.outgoing(node.id)

            incoming.size >= MIN_INCOMING_FOR_DUPLICATION &&
                    outgoing.isEmpty()
        }
    }

    private fun duplicateTerminalNode(
        node: DiagramNode,
        nodes: MutableList<DiagramNode>,
        edges: MutableList<DiagramEdge>
    ) {

        val incoming =
            edges.filter {
                it.target == node.id
            }

        if (incoming.size < MIN_INCOMING_FOR_DUPLICATION) {
            return
        }

        /*
         * Удаляем оригинальный visual node.
         *
         * Логическое состояние никуда не исчезает —
         * вместо него появятся visual copies.
         */
        nodes.removeIf {
            it.id == node.id
        }

        /*
         * Удаляем старые incoming edges.
         */
        edges.removeAll(incoming.toSet())

        incoming.forEachIndexed { index, edge ->

            val copyId =
                createCopyId(
                    node,
                    edge,
                    index
                )

            val copy =
                node.copy(
                    id = copyId,
                    visualCopy = true,
                    preferredParentId = edge.source,
                    placement = DiagramNode.Placement.SIDE
                )

            nodes += copy

            /*
             * Перенаправляем конкретный transition
             * на его собственную visual copy.
             */
            edges += edge.copy(
                target = copyId
            )
        }
    }

    private fun createCopyId(
        node: DiagramNode,
        edge: DiagramEdge,
        index: Int
    ): String {

        return buildString {
            append(node.logicalId)
            append("__copy__")
            append(edge.source)
            append("__")
            append(index)
        }
    }
}